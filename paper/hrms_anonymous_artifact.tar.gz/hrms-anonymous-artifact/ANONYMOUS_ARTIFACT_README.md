# Anonymous HRMS submission artifact

This deterministic bundle contains the paper source/PDF, implementation, tests, frozen headline simulations, aggregate CivilComments-derived results, and the self-contained final public-TE clustered cohort.

Raw ENCODE/UCSC source downloads, CivilComments text, caches, failed or exploratory result trees, and row-level test predictions/losses are intentionally excluded. The TE selection-loss table is included so the sealed HRMS selection analysis can be rerun without reading the test table. Candidate training can be rerun from the bundled clustered cohort.

`ARTIFACT_MANIFEST.sha256` authenticates every other file in this bundle. `ANONYMIZATION_TRANSFORMS.json` records the portable-path transformation applied to source manifests; scientific values and result tables are not rewritten. See `ARTIFACT.md` for commands and claim boundaries.
